from flask import Flask, render_template, request, redirect, session, send_from_directory, jsonify, has_request_context
import os
import mysql.connector
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import timedelta, datetime
import logging
import uuid  # 🔹 Added for session ID generation

app = Flask(__name__)
app.secret_key = 'your_secret_key'
app.permanent_session_lifetime = timedelta(minutes=10)

# === LOGGING SETUP ===
os.makedirs('logs', exist_ok=True)

class SafeFormatter(logging.Formatter):
    def format(self, record):
        if 'ip' not in record.__dict__:
            record.__dict__['ip'] = 'N/A'
        return super().format(record)

backend_logger = logging.getLogger('backend')
backend_handler = logging.FileHandler('logs/backend.log')
backend_handler.setFormatter(SafeFormatter('%(asctime)s %(levelname)s [%(ip)s]: %(message)s'))
backend_logger.addHandler(backend_handler)
backend_logger.setLevel(logging.INFO)

frontend_logger = logging.getLogger('frontend')
frontend_handler = logging.FileHandler('logs/frontend.log')
frontend_handler.setFormatter(SafeFormatter('%(asctime)s %(levelname)s [%(ip)s]: %(message)s'))
frontend_logger.addHandler(frontend_handler)
frontend_logger.setLevel(logging.INFO)

class IPLoggerAdapter(logging.LoggerAdapter):
    def process(self, msg, kwargs):
        try:
            ip = request.remote_addr if has_request_context() else 'N/A'
        except:
            ip = 'N/A'
        return msg, {'extra': {'ip': ip}}

backend_log = IPLoggerAdapter(backend_logger, {})
frontend_log = IPLoggerAdapter(frontend_logger, {})

# === MYSQL SETUP ===
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    database="user_uploads"
)
cursor = db.cursor()

UPLOAD_ROOT = os.path.join(os.getcwd(), 'details')
BROCHURE_PATH = r'K:\Vulnerable_Web\brochure'

@app.route('/')
def home():
    return redirect('/login')

@app.route('/signup', methods=['GET'])
def signup_page():
    if 'username' in session:
        return redirect('/login')
    return render_template('signup.html')

@app.route('/signup', methods=['POST'])
def signup_post():
    username = request.form['username']
    last_name = request.form['last_name']
    mobile = request.form['mobile']
    college = request.form['college']
    year = request.form['year']
    email = request.form['email']
    password = request.form['password']

    # === Mobile number validation ===
    if not mobile.isdigit() or len(mobile) != 10:
        return jsonify({'success': False, 'message': "Invalid mobile number. Must be 10 digits."})

    # === Password strength check ===
    if len(password) < 8 or not any(c.isupper() for c in password) or \
       not any(c.isdigit() for c in password) or not any(not c.isalnum() for c in password):
        return jsonify({'success': False, 'message': "Weak password"})

    hashed_password = generate_password_hash(password)
    try:
        cursor.execute("""INSERT INTO users 
            (username, last_name, mobile, college_name, passed_out_year, password_hash, email) 
            VALUES (%s, %s, %s, %s, %s, %s, %s)""",
            (username, last_name, mobile, college, year, hashed_password, email))
        db.commit()

        os.makedirs(os.path.join(UPLOAD_ROOT, username), exist_ok=True)
        backend_log.info(f"[SIGNUP] Success | User: {username}, Email: {email}, College: {college}, Year: {year}")
        return jsonify({'success': True})
    except mysql.connector.Error as err:
        backend_log.error(f"[SIGNUP] Failed | User: {username}, Email: {email} | Error: {err}")
        return jsonify({'success': False, 'message': str(err)})

@app.route('/login', methods=['GET'])
def login_page():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login_post():
    identifier = request.form['identifier']
    password = request.form['password']

    cursor.execute("""
        SELECT id, username, password_hash, failed_attempts, is_locked, last_failed_login 
        FROM users 
        WHERE username = %s OR email = %s
    """, (identifier, identifier))
    result = cursor.fetchone()
    cursor.fetchall()

    if result:
        user_id, username, password_hash, failed_attempts, is_locked, last_failed = result

        if is_locked:
            if last_failed and datetime.now() - last_failed > timedelta(minutes=15):
                cursor.execute("UPDATE users SET failed_attempts = 0, is_locked = FALSE WHERE id = %s", (user_id,))
                db.commit()
                is_locked = False
                failed_attempts = 0
            else:
                backend_log.warning(f"[LOGIN] Locked | Identifier: {identifier} | Attempts: {failed_attempts}")
                return jsonify({'success': False, 'message': 'Account is temporarily locked. Try again in 15 minutes.'})

        if check_password_hash(password_hash, password):
            session['user_id'] = user_id
            session['username'] = username
            session['session_id'] = str(uuid.uuid4())  # 🔹 Generate unique session ID
            session.permanent = True
            cursor.execute("UPDATE users SET failed_attempts = 0 WHERE id = %s", (user_id,))
            db.commit()

            backend_log.info(f"[LOGIN] Success | Session Started | Session ID: {session['session_id']} | User: {username}")
            return jsonify({'success': True})
        else:
            failed_attempts += 1
            cursor.execute("UPDATE users SET failed_attempts = %s, last_failed_login = %s WHERE id = %s",
                           (failed_attempts, datetime.now(), user_id))

            if failed_attempts >= 5:
                cursor.execute("UPDATE users SET is_locked = TRUE WHERE id = %s", (user_id,))
                backend_log.warning(f"[LOGIN] Locked after 5 fails | Identifier: {identifier}")
                db.commit()
                return jsonify({'success': False, 'message': 'Too many failed attempts. Account locked for 15 minutes.'})

            db.commit()
            backend_log.warning(f"[LOGIN] Failed | Identifier: {identifier} | Attempts: {failed_attempts}")
            return jsonify({'success': False, 'message': f'Invalid credentials. Attempts left: {5 - failed_attempts}'})
    else:
        backend_log.warning(f"[LOGIN] Failed | Unknown user: {identifier}")
        return jsonify({'success': False, 'message': 'Invalid username/email or password'})

@app.route('/dashboard')
def dashboard():
    if 'username' not in session:
        return redirect('/login')
    return render_template('dashboard.html', username=session['username'])

@app.route('/submit-files', methods=['POST'])
def submit_files():
    if 'username' not in session:
        return redirect('/login')

    resume = request.files.get('resume')
    bonafide = request.files.get('bonafide')
    username = session['username']
    user_id = session['user_id']
    session_id = session.get('session_id', 'unknown')

    if resume and not resume.filename.lower().endswith('.pdf'):
        return "Resume must be a PDF file.", 400

    if bonafide and not bonafide.filename.lower().endswith(('.jpg', '.jpeg', '.png')):
        return "Bonafide must be an image file (.jpg, .jpeg, .png).", 400

    if resume and bonafide:
        user_folder = os.path.join(UPLOAD_ROOT, username)
        os.makedirs(user_folder, exist_ok=True)
        resume_path = os.path.join(user_folder, resume.filename)
        bonafide_path = os.path.join(user_folder, bonafide.filename)

        resume.save(resume_path)
        bonafide.save(bonafide_path)

        cursor.execute("INSERT INTO uploads (user_id, file_type, file_path) VALUES (%s, %s, %s)",
                       (user_id, 'resume', resume_path))
        cursor.execute("INSERT INTO uploads (user_id, file_type, file_path) VALUES (%s, %s, %s)",
                       (user_id, 'bonafide', bonafide_path))
        db.commit()

        backend_log.info(f"[UPLOAD] Success | Session: {session_id} | User: {username} | Files: Resume + Bonafide")
        return '''
            <script>
              alert("Thanks for applying! Both files uploaded successfully.");
              window.location.href = "/dashboard";
            </script>
        '''
    return "Please upload both required files.", 400

@app.route('/download-brochure')
def download_brochure():
    if 'username' not in session:
        return redirect('/login')
    return send_from_directory(BROCHURE_PATH, "broc.pdf", as_attachment=True)

@app.route('/logout')
def logout():
    sid = session.get('session_id', 'unknown')
    username = session.get('username', 'unknown')
    backend_log.info(f"[LOGOUT] Session Ended | Session ID: {sid} | User: {username}")
    session.clear()
    return redirect('/login')

@app.route('/log-frontend', methods=['POST'])
def log_frontend():
    data = request.get_json()
    message = data.get("message", "")
    level = data.get("level", "info")

    if level == "error":
        frontend_log.error(f"[FRONTEND] {message}")
    elif level == "warning":
        frontend_log.warning(f"[FRONTEND] {message}")
    else:
        frontend_log.info(f"[FRONTEND] {message}")

    return jsonify({"status": "logged"})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5600)
